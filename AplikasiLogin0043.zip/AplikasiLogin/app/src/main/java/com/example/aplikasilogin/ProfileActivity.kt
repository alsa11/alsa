package com.example.aplikasilogin

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity

class ProfileActivity : AppCompatActivity() {

    private lateinit var editProfileLauncher: ActivityResultLauncher<Intent>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_profile)

        // Inisialisasi Objek
        var tvNIM = findViewById<TextView>(R.id.tvNIM)
        var tvNama = findViewById<TextView>(R.id.tvNama)
        var tvEmail = findViewById<TextView>(R.id.tvEmail)
        val btnEdit = findViewById<Button>(R.id.btnProfileUpdate)
        val btnKeluar = findViewById<Button>(R.id.btnProfileKeluar)

        // Ambil Data Intent
        val dataNIM = intent.getStringExtra("nim").toString()
        val dataNama = intent.getStringExtra("nama").toString()
        val dataEmail = intent.getStringExtra("email").toString()

        // Tampilkan Data Intent
        tvNIM.text = dataNIM
        tvNama.text = dataNama
        tvEmail.text = dataEmail

        // Nambah ini Inisialisasi ActivityResultLauncher
        editProfileLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == RESULT_OK) {
                val resultIntent = result.data
                val updatedNama = resultIntent?.getStringExtra("updated_nama")
                val updatedEmail = resultIntent?.getStringExtra("updated_email")

                // Update TextView dengan data yang diperbarui
                tvNama.text = updatedNama
                tvEmail.text = updatedEmail

            }
        }
        // Button Ubah
        btnEdit.setOnClickListener {
            val intent = Intent(this, EditProfileActivity::class.java)
            intent.putExtra("nim", dataNIM)
            intent.putExtra("nama", dataNama)
            intent.putExtra("email", dataEmail)
            editProfileLauncher.launch(intent) // Menggunakan launcher
        }

        // Button Keluar
        btnKeluar.setOnClickListener {
            finish()
        }
    }
}