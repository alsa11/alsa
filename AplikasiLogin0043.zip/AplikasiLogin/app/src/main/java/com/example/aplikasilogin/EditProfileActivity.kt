package com.example.aplikasilogin

import android.content.ContentValues
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.contentValuesOf
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class EditProfileActivity : AppCompatActivity() {

    private  lateinit var databaseHelper: DBHelper

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_edit_profile)

        databaseHelper= DBHelper(this)

        val dataNIM: String = intent.getStringExtra("nim").toString()
        val dataNama: String = intent.getStringExtra("nama").toString()
        val dataEmail: String = intent.getStringExtra("email").toString()

        val editNIM = findViewById<EditText>(R.id.editNIM)
        val editNama = findViewById<EditText>(R.id.editNama)
        val editEmail = findViewById<EditText>(R.id.editEmail)
        val editPassword = findViewById<EditText>(R.id.editPassword)

        editNIM.isEnabled = false
        editNIM.setText(dataNIM)
        editNama.setText(dataNama)
        editEmail.setText(dataEmail)

        val btnKonfirmasi = findViewById<Button>(R.id.btnKonfirmasi)

        btnKonfirmasi.setOnClickListener{
            val newNama: String = editNama.text.toString()
            val newEmail: String = editEmail.text.toString()
            val newPassword: String = editPassword.text.toString()

            if(newNama.equals("") || newEmail.equals("")){
                Toast.makeText(applicationContext,"Nama dan Email tidak boleh kosong",
                    Toast.LENGTH_LONG).show()
            }else{

                val db = databaseHelper.writableDatabase

                var updateValues: ContentValues? = null
                if(newPassword.equals("")){
                    updateValues = ContentValues().apply {
                        put("nama", newNama)
                        put("email", newEmail)
                    }
                }else{
                    updateValues = ContentValues().apply{
                        put("nama", newNama)
                        put("email", newEmail)
                        put("password", newPassword)
                    }
                }

                val result = db.update("TBL_MHS", updateValues,
                    "nim = ?", arrayOf(dataNIM) )

                if (result > 0) {
                    val intent: Intent = Intent (this, ProfileActivity::class.java)
                    intent.putExtra("nim", dataNIM)
                    intent.putExtra("nama", newNama)
                    intent.putExtra("email", newEmail)
                    startActivity(intent)

                    Toast.makeText(applicationContext, "Berhasil memperbarui data",
                        Toast.LENGTH_LONG).show()

                } else {
                    Toast.makeText(applicationContext, "Gagal memperbarui data",
                        Toast.LENGTH_LONG).show()
                }
            }
        }
        val btnBatal = findViewById<Button>(R.id.btnEditBatal)
        btnBatal.setOnClickListener{
            finish()
        }

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
    }
}