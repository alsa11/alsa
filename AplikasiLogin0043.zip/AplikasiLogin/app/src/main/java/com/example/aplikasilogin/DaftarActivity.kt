package com.example.aplikasilogin

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteOpenHelper
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat


class DaftarActivity : AppCompatActivity() {

    private lateinit var databaseHelper: DBHelper // TAMBAH INI

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_daftar)

        databaseHelper = DBHelper(this) // TAMBAH INI

        var inputDataNIM: EditText = findViewById(R.id.inpNIM)
        var inputDataNama: EditText = findViewById(R.id.inpNama)
        var inputDataEmail: EditText = findViewById(R.id.inpEmail)
        var inputDataPassword: EditText = findViewById(R.id.inpPassword)
        val btnAksiDaftar: Button = findViewById(R.id.buttonDaftar)
        val btnAksiBersih: Button = findViewById(R.id.buttonBersih)
        val btnAksiBatal: Button = findViewById(R.id.buttonBatal)


        btnAksiBersih.setOnClickListener {
            inputDataNIM.setText("")
            inputDataNama.setText("")
            inputDataEmail.setText("")
            inputDataPassword.setText("")
        }

        btnAksiDaftar.setOnClickListener {

            if (inputDataNIM.equals("") || inputDataNama.equals("")
                || inputDataEmail.equals("") || inputDataPassword.equals("")
            ) {
                Toast.makeText(applicationContext, "Tidak boleh ada yang kosong", Toast.LENGTH_LONG)
                    .show()
            }

            // Buka Akses DB

            val nim: String = inputDataNIM.text.toString()
            val nama: String = inputDataNama.text.toString()
            val email: String = inputDataEmail.text.toString()
            val password: String = inputDataPassword.text.toString()

            val db = databaseHelper.readableDatabase
            val insertValues = ContentValues().apply {
                put("nim", nim)
                put("nama", nama)
                put("email", email)
                put("password", password)
            }
            val result = db.insert("TBL_MHS", null, insertValues)

            db.close()

            if(result !=-1L)
            {
                Toast.makeText(applicationContext,"Kueri Sukses",Toast.LENGTH_SHORT).show()
                finish()
            }
            else
                Toast.makeText(applicationContext,"Kueri Gagal",Toast.LENGTH_SHORT).show()
        }
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
    }
}